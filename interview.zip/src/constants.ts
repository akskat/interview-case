export const POKEMONS = [
    "bulbasaur",
    "charmander",
    "squirtle",
    "caterpie",
    "weedle",
    "pidgey",
    "pikachu",
    "rattata",
    "abra",
    "machop",
];

export const AVAILABLE_COLUMNS = [
    "name",
    "picture",
    "id",
    "weight",
    "height",
    "types",
];